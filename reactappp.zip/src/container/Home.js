import React from "react";
import Header from "../components/Header";

const Home = () =>{
    return(
        <>
        <h1>This is Home Page</h1>
        </>
    )
}


export default Home;
